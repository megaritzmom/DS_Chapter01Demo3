#include <stdio.h>
# define MAX_ELEMENTS 5
#pragma warning(disable:4996)

int main(void)
{
	int i;
	int my_array[MAX_ELEMENTS];

	printf("This program will accept integers from the user, put them into");
	printf(" an array, and output some of them.\n");

	for (i = 0; i < MAX_ELEMENTS; i++)
	{
		printf("Enter an integer: ");
		scanf("%d", my_array + i);
	}

	printf("\n%d", *my_array);
	printf("\n%d", *(my_array+2));

	// Hold console open for user to finish reading.
	printf("\nPress the Enter key a time or two to end the program.\n");
	getchar();
	getchar();

	// Use return 0 since main returns an int.
	return 0;
}